package com.example.banking.service;

import com.example.banking.model.Account;
import com.example.banking.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {
    @Autowired private AccountRepository repo;

    public Account create(Account a) {
        return repo.save(a);
    }
    public Account find(Long id) {
        return repo.findById(id).orElse(null);
    }
    public Account update(Account a) {
        return repo.save(a);
    }
}