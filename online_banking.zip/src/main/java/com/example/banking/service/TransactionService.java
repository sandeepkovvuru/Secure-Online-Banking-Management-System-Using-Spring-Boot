package com.example.banking.service;

import com.example.banking.model.Transaction;
import com.example.banking.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransactionService {
    @Autowired private TransactionRepository repo;

    public Transaction record(Transaction t) {
        return repo.save(t);
    }
}