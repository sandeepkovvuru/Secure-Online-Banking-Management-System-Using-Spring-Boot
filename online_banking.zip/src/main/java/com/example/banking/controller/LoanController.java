package com.example.banking.controller;

import com.example.banking.model.Loan;
import com.example.banking.service.LoanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/loans")
public class LoanController {
    @Autowired private LoanService service;

    @GetMapping
    public String list(Model m) {
        m.addAttribute("loans", service.repo.findAll());
        return "loans";
    }

    @PostMapping("/apply")
    public String apply(@ModelAttribute Loan loan) {
        service.apply(loan);
        return "redirect:/loans";
    }
}