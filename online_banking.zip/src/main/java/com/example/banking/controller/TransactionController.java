package com.example.banking.controller;

import com.example.banking.model.Transaction;
import com.example.banking.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/transactions")
public class TransactionController {
    @Autowired private TransactionService service;

    @GetMapping
    public String list(Model m) {
        m.addAttribute("transactions", service.repo.findAll());
        return "transactions";
    }
}