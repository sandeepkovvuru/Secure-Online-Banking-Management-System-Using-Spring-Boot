package com.example.banking.service;

import com.example.banking.model.Loan;
import com.example.banking.repository.LoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoanService {
    @Autowired private LoanRepository repo;

    public Loan apply(Loan l) {
        l.setStatus("PENDING");
        return repo.save(l);
    }
    public Loan approve(Long id) {
        Loan l = repo.findById(id).orElse(null);
        if (l != null) {
            l.setStatus("APPROVED");
            repo.save(l);
        }
        return l;
    }
}